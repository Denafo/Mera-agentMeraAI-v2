#!/usr/bin/env python3
"""V2.5.2 static smoke + regression checks (not a Gradle compile)."""
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/demor/meraai'
manifest=root/'app/src/main/AndroidManifest.xml'
files=['MainActivity.kt','MemoryStore.kt','Brain.kt','Web.kt','PinLock.kt','CrashCapture.kt']
assert all((src/f).is_file() for f in files), 'missing Kotlin file'
app=ET.parse(manifest).getroot().find('application')
android_ns='{http://schemas.android.com/apk/res/android}'
assert app is not None and app.attrib.get(android_ns+'allowBackup')=='false'
build=(root/'app/build.gradle.kts').read_text()
assert 'applicationId = "com.demor.meraai.personal252"' in build
assert 'litertlm-android:0.18.0' in build
assert 'jvmTarget.set(JvmTarget.JVM_17)' in build
assert 'kotlinOptions {' not in build
store=(src/'MemoryStore.kt').read_text()
for signature in ['fun newChat()', 'fun switchChat(', 'fun deleteChat(',
                  'fun listChats()', 'fun updateKnowledge(', 'fun removeKnowledge(',
                  'fun proposeImprovement(', 'fun setImprovementState(',
                  'fun selfTest()', 'cipher.init(Cipher.ENCRYPT_MODE, key)',
                  'cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))']:
    assert signature in store, signature
assert 'cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec' not in store
assert 'AES/GCM/NoPadding' in store and 'AndroidKeyStore' in store
main=(src/'MainActivity.kt').read_text()
for signature in ['showPinGate()', 'showChatManager()', 'showMemoryManager()',
                  'showImprovementManager()', 'store.newChat()', 'store.loadMessages(9)',
                  '"/diagnose"', '"/improve"', '"/approve", "/reject"',
                  '"/editmemory"', '"/memorytest"', 'safeSaveMessage("user", text)']:
    assert signature in main, signature
assert 'getBoolean("auto_learn", false)' in main
assert 'val learnedId = store.addKnowledge(found.first, found.second, "wikipedia")' in main
assert 'MemoryStore.Entry(learnedId, found.first, found.second, "wikipedia")' in main
assert 'MemoryStore.Entry(found.first, found.second, "wikipedia")' not in main
pin=(src/'PinLock.kt').read_text()
assert 'PBKDF2WithHmacSHA256' in pin and 'MessageDigest.isEqual' in pin
assert 'conv.sendMessage(prompt)' in (src/'Brain.kt').read_text()
assert 'ThinkingConfig(enableThinking = false, thinkingTokenBudget = 0)' in (src/'Brain.kt').read_text()
assert 'CountDownLatch' not in main
assert 'brain.ask(prompt)' in main
print('PASS: project structure, v2.5.2 features, encrypted files, updated Kotlin DSL')
print('NOTE: Android compilation, memory transfer and phone behavior are NOT verified here')
