package com.demor.meraai

import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.ThinkingConfig

/** Phone par chalne wala offline AI model (LiteRT-LM). */
class Brain {

    @Volatile
    private var engine: Engine? = null

    @Volatile
    private var conversation: Conversation? = null

    @Volatile
    private var firstTurn = true

    val ready: Boolean
        get() = conversation != null

    @Synchronized
    fun load(modelPath: String) {
        close()
        // Smaller KV-cache to limit additional memory allocated at first inference.
        // This does NOT guarantee all devices can execute the model.
        val config = EngineConfig(
            modelPath = modelPath,
            backend = Backend.CPU(),
            maxNumTokens = 1024
        )
        val e = Engine(config)
        e.initialize()
        engine = e
        conversation = e.createConversation(ConversationConfig(maxOutputToken = 128, thinkingConfig = ThinkingConfig(enableThinking = false, thinkingTokenBudget = 0)))
        firstTurn = true
    }

    @Synchronized
    fun reset() {
        val e = engine ?: return
        try {
            conversation?.close()
        } catch (t: Throwable) {
            // ignore
        }
        conversation = e.createConversation(ConversationConfig(maxOutputToken = 128, thinkingConfig = ThinkingConfig(enableThinking = false, thinkingTokenBudget = 0)))
        firstTurn = true
    }

    @Synchronized
    fun close() {
        try {
            conversation?.close()
        } catch (t: Throwable) {
            // ignore
        }
        try {
            engine?.close()
        } catch (t: Throwable) {
            // ignore
        }
        conversation = null
        engine = null
    }

    /**
     * LiteRT-LM synchronous inference. Call ONLY on the app's background executor.
     * Avoids callback streams that sometimes never call onDone, leaving the UI busy.
     * Thinking is disabled at conversation creation so Qwen does not spend a tiny
     * output-token allowance on hidden reasoning instead of an answer.
     */
    @Synchronized
    fun ask(userText: String): String {
        val conv = conversation ?: throw IllegalStateException("Model load nahi hai")
        val prompt = if (firstTurn) PREAMBLE + "\n\n" + userText else userText
        firstTurn = false
        return conv.sendMessage(prompt).toString().trim()
    }

    companion object {
        private const val PREAMBLE =
            "Tum 'Mera AI' ho, user ka personal offline assistant. User jis bhasha me likhe " +
                "(Hindi, Hinglish ya English) usi me chhota, saaf aur kaam ka jawab do. " +
                "Agar 'Saved jaankari' di gayi ho aur wo sawal se judi ho to usse madad lo; " +
                "warna apni jaankari se jawab do, aur pakka na ho to saaf bata do."
    }
}
