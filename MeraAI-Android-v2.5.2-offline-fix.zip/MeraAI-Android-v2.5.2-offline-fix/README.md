# Mera AI v2.5.2 Offline Response Test

This is a source-level experiment based on the user-tested v2.5.1 app. It targets the observed symptom: model says ready but a message produces a blank reply and the Send button stays disabled.

## Changes

- Uses LiteRT-LM `Conversation.sendMessage(prompt)` on the existing single-thread background executor, instead of callbacks that can fail to signal `onDone`.
- Turns thinking off in the model conversation (`ThinkingConfig(enableThinking = false, thinkingTokenBudget = 0)`) to prioritize a visible answer for Qwen3.
- Limits completion to 128 tokens on CPU. Displays a real generation error or an empty-answer message, not an empty bubble.
- Preserves PIN, encrypted memory, chat management, improvement queue, and diagnostic commands.
- Uses a separate Android application ID `com.demor.meraai.personal252` to avoid replacing v2.5.1, because GitHub debug builds from separate runs may have different signing keys. **Memories do not transfer automatically.**

## Limitations

- `sendMessage` can still hang inside a native library or run out of memory. The UI will wait until the synchronous call returns; this build does **not** claim to solve all native inference issues.
- A phone with ~1.16 GB available RAM may struggle to generate with the Qwen3-0.6B model. If the test is unresponsive, do not keep repeating it.
- The code was statically validated and ZIP integrity checked; full Android Gradle compilation and on-device generation are NOT verified in this environment.

## Test

1. Build debug APK via `.github/workflows/build-meraai-v252.yml`.
2. Install separately. Create a new PIN, test `/memorytest`, then import the downloaded Qwen3-0.6B `.litertlm` model.
3. Turn off network and Wikipedia learning; send `2 + 2 = ? Answer in one line.` once.
4. If no reply, check `/status` only if the button becomes enabled. If the app is unresponsive, stop repeated tests and collect Android logcat for a native error.

Never uninstall v2.5.1 to install this test.
