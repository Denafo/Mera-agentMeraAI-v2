package com.demor.meraai

import android.content.Context
import java.io.File

/** Minimal private Java/Kotlin exception diagnostics. Does not capture user prompts.
 * Native SIGSEGV, SIGABRT and low-memory process kills may not create a report.
 */
object CrashCapture {
    private const val FILE = "last_java_crash.txt"
    fun install(context: Context) {
        val dir = context.filesDir
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, failure ->
            try {
                val frames = failure.stackTrace.take(12).joinToString("\n") {
                    it.className + "." + it.methodName + ":" + it.lineNumber
                }
                File(dir, FILE).writeText(
                    "Uncaught exception: " + failure.javaClass.name + "\n" +
                    "Thread: " + thread.name + "\n" + frames
                )
            } catch (_: Exception) {
                // Preserve standard Android crash handling if private storage fails.
            }
            if (previous != null) previous.uncaughtException(thread, failure)
            else android.os.Process.killProcess(android.os.Process.myPid())
        }
    }
    fun hasReport(context: Context): Boolean = File(context.filesDir, FILE).exists()
    fun report(context: Context): String = try {
        File(context.filesDir, FILE).takeIf { it.exists() }?.readText()?.take(3000)
            ?: "Koi Java crash report nahi mila. Native crash/OOM ke liye Android bug report chahiye."
    } catch (_: Exception) { "Crash report read nahi hua." }
}
