package com.demor.meraai

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.AtomicFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Per-install Android Keystore encryption for chats, knowledge and improvement tickets.
 * All state stays in app-private storage. Uninstall removes the Keystore key and data.
 * Existing v2.4 format can migrate *within the same app ID*; separate app IDs cannot
 * read each other's private storage (this v2.5 test app intentionally uses its own ID).
 */
class MemoryStore(private val dir: File) {
    data class Msg(val role: String, val text: String)
    data class Entry(val id: String, val title: String, val text: String, val source: String)
    data class ChatInfo(val id: String, val title: String, val updated: Long, val count: Int)
    data class Improvement(val id: String, val issue: String, val proposal: String, val state: String)

    private val legacyChat = File(dir, "chat_history.enc")
    private val chats = File(dir, "chats_v3.enc")
    private val knowledge = File(dir, "knowledge.enc")
    private val improvements = File(dir, "improvements.enc")
    private val key: SecretKey by lazy { fetchKey() }

    init {
        check(dir.isDirectory || dir.mkdirs()) { "Cannot create private memory directory" }
        migrateLegacyPlaintext()
        migrateSingleChat()
    }

    private fun id(): String = UUID.randomUUID().toString().substring(0, 8)

    // -------- Encrypted multi-conversation history --------
    @Synchronized
    fun currentChatId(): String = getChats().getString("current")

    @Synchronized
    fun listChats(): List<ChatInfo> {
        val sessions = getChats().getJSONArray("sessions")
        return (0 until sessions.length()).mapNotNull { i ->
            sessions.optJSONObject(i)?.let { s ->
                ChatInfo(s.getString("id"), s.optString("title", "Naya chat"),
                    s.optLong("updated"), s.optJSONArray("messages")?.length() ?: 0)
            }
        }.sortedByDescending { it.updated }
    }

    @Synchronized
    fun newChat(): String {
        val data = getChats()
        val new = emptySession()
        data.getJSONArray("sessions").put(new)
        data.put("current", new.getString("id"))
        write(chats, JSONArray().put(data))
        return new.getString("id")
    }

    @Synchronized
    fun switchChat(id: String): Boolean {
        val data = getChats()
        val sessions = data.getJSONArray("sessions")
        if ((0 until sessions.length()).none { sessions.getJSONObject(it).optString("id") == id }) return false
        data.put("current", id)
        write(chats, JSONArray().put(data))
        return true
    }

    @Synchronized
    fun deleteChat(id: String): Boolean {
        val data = getChats()
        val old = data.getJSONArray("sessions")
        val updated = JSONArray()
        var found = false
        for (i in 0 until old.length()) {
            val session = old.getJSONObject(i)
            if (session.optString("id") == id) found = true else updated.put(session)
        }
        if (!found) return false
        if (updated.length() == 0) updated.put(emptySession())
        data.put("sessions", updated)
        if (data.getString("current") == id) data.put("current", updated.getJSONObject(0).getString("id"))
        write(chats, JSONArray().put(data))
        return true
    }

    @Synchronized
    fun addMessage(role: String, text: String) {
        require(role == "user" || role == "assistant")
        val data = getChats()
        val session = currentSession(data)
        val messages = session.getJSONArray("messages")
        messages.put(JSONObject().put("r", role).put("t", text.take(20000)))
        if (role == "user" && session.optString("title") == "Naya chat")
            session.put("title", text.replace('\n', ' ').take(42))
        session.put("updated", System.currentTimeMillis())
        // Bound growth per conversation; preserve the latest 400 messages.
        if (messages.length() > 400) {
            val trimmed = JSONArray()
            for (i in (messages.length() - 400) until messages.length()) trimmed.put(messages.get(i))
            session.put("messages", trimmed)
        }
        write(chats, JSONArray().put(data))
    }

    @Synchronized
    fun loadMessages(limit: Int): List<Msg> {
        val msgs = currentSession(getChats()).getJSONArray("messages")
        val start = (msgs.length() - limit.coerceAtLeast(0)).coerceAtLeast(0)
        return (start until msgs.length()).mapNotNull { i ->
            msgs.optJSONObject(i)?.let { Msg(it.optString("r"), it.optString("t")) }
        }
    }

    @Synchronized
    fun clearChat() {
        val data = getChats()
        val session = currentSession(data)
        session.put("messages", JSONArray())
        session.put("title", "Naya chat")
        write(chats, JSONArray().put(data))
    }

    private fun emptySession(): JSONObject = JSONObject()
        .put("id", id()).put("title", "Naya chat")
        .put("updated", System.currentTimeMillis())
        .put("messages", JSONArray())

    private fun getChats(): JSONObject {
        if (!chats.exists()) {
            val first = emptySession()
            return JSONObject().put("current", first.getString("id"))
                .put("sessions", JSONArray().put(first))
        }
        val data = read(chats).getJSONObject(0)
        if (data.getJSONArray("sessions").length() == 0) error("No chat sessions")
        return data
    }

    private fun currentSession(data: JSONObject): JSONObject {
        val id = data.getString("current")
        val sessions = data.getJSONArray("sessions")
        for (i in 0 until sessions.length()) {
            val s = sessions.getJSONObject(i)
            if (s.optString("id") == id) return s
        }
        error("Current chat missing")
    }

    private fun migrateSingleChat() {
        if (!legacyChat.exists() || chats.exists()) return
        val data = getChats()
        currentSession(data).put("messages", read(legacyChat))
        currentSession(data).put("title", "Purani conversation")
        write(chats, JSONArray().put(data))
        // Delete only after the new encrypted store commits successfully.
        check(legacyChat.delete()) { "Old encrypted chat cleanup failed" }
    }

    // -------- Explicit long-term knowledge --------
    @Synchronized
    fun addKnowledge(title: String, text: String, source: String): String {
        val k = id()
        val data = read(knowledge)
        data.put(JSONObject().put("id", k).put("ti", title.take(100))
            .put("tx", text.take(12000)).put("s", source.take(400)))
        write(knowledge, data)
        return k
    }

    @Synchronized
    fun allKnowledge(): List<Entry> {
        val data = read(knowledge)
        return (0 until data.length()).mapNotNull { i ->
            data.optJSONObject(i)?.let { e ->
                Entry(e.optString("id").ifBlank { "old-$i" }, e.optString("ti"),
                    e.optString("tx"), e.optString("s"))
            }
        }
    }

    fun knowledgeCount() = allKnowledge().size

    @Synchronized
    fun updateKnowledge(id: String, newText: String): Boolean {
        if (newText.isBlank()) return false
        val data = read(knowledge)
        for (i in 0 until data.length()) {
            val e = data.getJSONObject(i)
            if (e.optString("id").ifBlank { "old-$i" } == id) {
                e.put("id", id).put("tx", newText.trim().take(12000))
                write(knowledge, data)
                return true
            }
        }
        return false
    }

    @Synchronized
    fun removeKnowledge(id: String): Boolean {
        val data = read(knowledge)
        val out = JSONArray()
        var removed = false
        for (i in 0 until data.length()) {
            val e = data.getJSONObject(i)
            if (e.optString("id").ifBlank { "old-$i" } == id) removed = true else out.put(e)
        }
        if (removed) write(knowledge, out)
        return removed
    }

    @Synchronized
    fun clearKnowledge() = write(knowledge, JSONArray())

    fun search(query: String, limit: Int): List<Entry> {
        val words = tokens(query)
        if (words.isEmpty()) return emptyList()
        val need = if (words.size >= 2) 2 else 1
        return allKnowledge()
            .map { e -> e to words.count { (e.title + " " + e.text).lowercase().contains(it) } }
            .filter { it.second >= need }
            .sortedByDescending { it.second }
            .take(limit.coerceAtLeast(0))
            .map { it.first }
    }

    private fun tokens(s: String) = s.lowercase()
        .split(Regex("[^\\p{L}\\p{M}\\p{N}]+"))
        .filter { it.length >= 3 && it !in STOP }
        .distinct()

    // -------- Approved improvement backlog (NO automatic code execution) --------
    @Synchronized
    fun proposeImprovement(issue: String): Improvement {
        require(issue.isNotBlank())
        val proposal = when {
            issue.contains("crash", true) || issue.contains("band", true) ->
                "Crash logs review karo, reproducible test banao, phir isolated build par fix test karo."
            issue.contains("memory", true) || issue.contains("yaad", true) ->
                "Encrypted memory read/write tests aur backup/recovery UX ka design review karo."
            issue.contains("slow", true) || issue.contains("hang", true) ->
                "Inference RAM, token budget aur UI responsiveness profile karo."
            else -> "Issue review karo, test case likho, safe change propose karo, approval ke baad naya signed build banao."
        }
        val item = Improvement(id(), issue.trim().take(300), proposal, "pending")
        val data = read(improvements)
        data.put(JSONObject().put("id", item.id).put("issue", item.issue)
            .put("proposal", item.proposal).put("state", item.state))
        write(improvements, data)
        return item
    }

    @Synchronized
    fun allImprovements(): List<Improvement> {
        val data = read(improvements)
        return (0 until data.length()).mapNotNull { i ->
            data.optJSONObject(i)?.let {
                Improvement(it.optString("id"), it.optString("issue"),
                    it.optString("proposal"), it.optString("state"))
            }
        }
    }

    @Synchronized
    fun setImprovementState(id: String, state: String): Boolean {
        require(state == "approved" || state == "rejected")
        val data = read(improvements)
        for (i in 0 until data.length()) {
            val item = data.getJSONObject(i)
            if (item.optString("id") == id) {
                item.put("state", state)
                write(improvements, data)
                return true
            }
        }
        return false
    }

    // -------- Self-check encryption without modifying personal data --------
    @Synchronized
    fun selfTest(): Boolean {
        val probe = File(dir, "encryption_probe.enc")
        return try {
            write(probe, JSONArray().put(JSONObject().put("probe", "ok")))
            read(probe).optJSONObject(0)?.optString("probe") == "ok"
        } finally {
            if (probe.exists()) probe.delete()
        }
    }

    private fun fetchKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun read(file: File): JSONArray {
        if (!file.exists()) return JSONArray()
        val bytes = AtomicFile(file).openRead().use { it.readBytes() }
        require(bytes.size >= 32 && bytes.copyOfRange(0, 4).contentEquals(MAGIC)) {
            "Invalid encrypted memory file: ${file.name}"
        }
        val iv = bytes.copyOfRange(4, 16)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        cipher.updateAAD(file.name.toByteArray(Charsets.UTF_8))
        return JSONArray(String(cipher.doFinal(bytes.copyOfRange(16, bytes.size)), Charsets.UTF_8))
    }

    private fun write(file: File, data: JSONArray) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val iv = requireNotNull(cipher.iv) { "Android Keystore did not return a GCM IV" }
        check(iv.size == 12) { "Unexpected AES-GCM IV size: ${iv.size}" }
        cipher.updateAAD(file.name.toByteArray(Charsets.UTF_8))
        val encrypted = cipher.doFinal(data.toString().toByteArray(Charsets.UTF_8))
        val atomic = AtomicFile(file)
        val output = atomic.startWrite()
        try {
            output.write(MAGIC)
            output.write(iv)
            output.write(encrypted)
            atomic.finishWrite(output)
        } catch (t: Throwable) {
            atomic.failWrite(output)
            throw t
        }
    }

    private fun migrateLegacyPlaintext() {
        for ((oldName, newFile) in listOf(
            "chat_history.jsonl" to legacyChat,
            "knowledge.jsonl" to knowledge
        )) {
            val old = File(dir, oldName)
            if (!old.exists()) continue
            if (!newFile.exists()) {
                val arr = JSONArray()
                old.forEachLine(Charsets.UTF_8) { line ->
                    if (line.isNotBlank()) {
                        try { arr.put(JSONObject(line)) } catch (_: Exception) { /* old damaged record */ }
                    }
                }
                write(newFile, arr)
            }
            check(old.delete()) { "Unable to remove plaintext memory after migration" }
        }
    }

    companion object {
        private const val KEY_ALIAS = "com.demor.meraai.memory.aes.v2"
        private val MAGIC = byteArrayOf('M'.code.toByte(), 'A'.code.toByte(),
            'I'.code.toByte(), '2'.code.toByte())
        private val STOP = setOf("the", "and", "what", "how", "who", "why", "for", "with",
            "can", "you", "please", "kya", "hai", "hain", "kaise", "kaun", "kyu", "kyun",
            "mera", "meri", "mere", "aap", "tum", "batao", "bata", "mein", "par")
    }
}
