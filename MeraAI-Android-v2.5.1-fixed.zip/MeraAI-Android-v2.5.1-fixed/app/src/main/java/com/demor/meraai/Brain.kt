package com.demor.meraai

import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.MessageCallback

/** Phone par chalne wala offline AI model (LiteRT-LM). */
class Brain {

    @Volatile
    private var engine: Engine? = null

    @Volatile
    private var conversation: Conversation? = null

    @Volatile
    private var firstTurn = true

    val ready: Boolean
        get() = conversation != null

    @Synchronized
    fun load(modelPath: String) {
        close()
        // Smaller KV-cache to limit additional memory allocated at first inference.
        // This does NOT guarantee all devices can execute the model.
        val config = EngineConfig(
            modelPath = modelPath,
            backend = Backend.CPU(),
            maxNumTokens = 1024
        )
        val e = Engine(config)
        e.initialize()
        engine = e
        conversation = e.createConversation(ConversationConfig(maxOutputToken = 160))
        firstTurn = true
    }

    @Synchronized
    fun reset() {
        val e = engine ?: return
        try {
            conversation?.close()
        } catch (t: Throwable) {
            // ignore
        }
        conversation = e.createConversation(ConversationConfig(maxOutputToken = 160))
        firstTurn = true
    }

    @Synchronized
    fun close() {
        try {
            conversation?.close()
        } catch (t: Throwable) {
            // ignore
        }
        try {
            engine?.close()
        } catch (t: Throwable) {
            // ignore
        }
        conversation = null
        engine = null
    }

    /** Jawab chunk-by-chunk aata hai. finish() ya fail() ek baar zaroor bulaya jaata hai. */
    fun ask(
        userText: String,
        chunk: (String) -> Unit,
        finish: () -> Unit,
        fail: (Throwable) -> Unit
    ) {
        val conv = conversation
        if (conv == null) {
            fail(IllegalStateException("Model load nahi hai"))
            return
        }
        val prompt: String
        if (firstTurn) {
            firstTurn = false
            prompt = PREAMBLE + "\n\n" + userText
        } else {
            prompt = userText
        }
        val callback = object : MessageCallback {
            override fun onMessage(message: Message) {
                chunk(message.toString())
            }

            override fun onDone() {
                finish()
            }

            override fun onError(throwable: Throwable) {
                fail(throwable)
            }
        }
        conv.sendMessageAsync(prompt, callback)
    }

    companion object {
        private const val PREAMBLE =
            "Tum 'Mera AI' ho, user ka personal offline assistant. User jis bhasha me likhe " +
                "(Hindi, Hinglish ya English) usi me chhota, saaf aur kaam ka jawab do. " +
                "Agar 'Saved jaankari' di gayi ho aur wo sawal se judi ho to usse madad lo; " +
                "warna apni jaankari se jawab do, aur pakka na ho to saaf bata do."
    }
}
