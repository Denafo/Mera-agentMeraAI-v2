package com.demor.meraai

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URI
import java.net.URL
import java.net.URLEncoder

/** Internet se seekhne ke tools (sirf tab chalte hain jab net ho). */
object Web {

    fun online(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /** HTTPS only. Reject local/private IPs and recheck every redirect. */
    fun get(url: String, timeoutMs: Int = 8000, maxBytes: Int = 1500000): String {
        var uri = URI(url)
        repeat(4) { redirects ->
            val host = uri.host ?: throw IOException("Invalid host")
            if (!uri.scheme.equals("https", true) || uri.userInfo != null ||
                (uri.port != -1 && uri.port != 443)) {
                throw IOException("Only public HTTPS URLs are supported")
            }
            if (host.equals("localhost", true) || host.endsWith(".local", true)) {
                throw IOException("Local addresses are not allowed")
            }
            val addresses = InetAddress.getAllByName(host)
            if (addresses.isEmpty() || addresses.any {
                    it.isAnyLocalAddress || it.isLoopbackAddress || it.isLinkLocalAddress ||
                        it.isSiteLocalAddress || it.isMulticastAddress || it.hostAddress == "169.254.169.254"
                }) {
                throw IOException("Private network addresses are not allowed")
            }
            val c = uri.toURL().openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.setRequestProperty("User-Agent", "MeraAI/2.0 (personal assistant app)")
            try {
                val code = c.responseCode
                if (code in 300..399) {
                    val location = c.getHeaderField("Location")
                        ?: throw IOException("Redirect without Location")
                    if (redirects == 3) throw IOException("Too many redirects")
                    uri = uri.resolve(location)
                } else {
                    if (code !in 200..299) throw IOException("HTTP $code")
                    val buf = ByteArrayOutputStream()
                    c.inputStream.use { ins ->
                        val bytes = ByteArray(8192)
                        while (buf.size() < maxBytes) {
                            val n = ins.read(bytes, 0, minOf(bytes.size, maxBytes - buf.size()))
                            if (n < 0) break
                            buf.write(bytes, 0, n)
                        }
                    }
                    return buf.toString("UTF-8")
                }
            } finally {
                c.disconnect()
            }
        }
        throw IOException("Redirect limit exceeded")
    }

    /** Wikipedia (Hindi ya English) se topic ka summary laao. Return: (title, text) */
    fun wiki(query: String): Pair<String, String>? {
        val q = query.trim().take(200)
        if (q.isEmpty()) return null
        var lang = "en"
        for (ch in q) {
            if (ch in 'ऀ'..'ॿ') {
                lang = "hi"
                break
            }
        }
        val base = "https://" + lang + ".wikipedia.org/w/api.php"
        val enc = URLEncoder.encode(q, "UTF-8")
        val s = JSONObject(get(base + "?action=query&list=search&srsearch=" + enc + "&srlimit=1&format=json"))
        val arr = s.getJSONObject("query").getJSONArray("search")
        if (arr.length() == 0) return null
        val title = arr.getJSONObject(0).getString("title")
        val t = URLEncoder.encode(title, "UTF-8")
        val p = JSONObject(
            get(base + "?action=query&prop=extracts&exintro=1&explaintext=1&redirects=1&titles=" + t + "&format=json")
        )
        val pages = p.getJSONObject("query").getJSONObject("pages")
        val key = pages.keys().next()
        val extract = pages.getJSONObject(key).optString("extract", "").trim()
        if (extract.isEmpty()) return null
        return Pair(title, extract.take(1500))
    }

    /** Kisi bhi web page ka text nikaalo. Return: (title, text) */
    fun page(rawUrl: String): Pair<String, String> {
        var url = rawUrl.trim()
        if (url.startsWith("http://")) url = "https://" + url.removePrefix("http://")
        if (!url.startsWith("https://")) url = "https://" + url
        val html = get(url, 12000)
        val titleRe = Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        val title = titleRe.find(html)?.groupValues?.get(1)?.trim() ?: url
        var t = html.replace(Regex("<(script|style|noscript)[\\s\\S]*?</\\1>", RegexOption.IGNORE_CASE), " ")
        t = t.replace(Regex("<[^>]+>"), " ")
        t = t.replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<")
            .replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'")
        t = t.replace(Regex("\\s+"), " ").trim()
        return Pair(title.take(120), t)
    }
}
