package com.demor.meraai

import android.content.SharedPreferences
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Local-only PIN verifier. Never stores the original PIN. */
class PinLock(private val prefs: SharedPreferences) {
    private val rng = SecureRandom()

    fun isConfigured(): Boolean =
        prefs.contains("pin_salt_v2") && prefs.contains("pin_hash_v2")

    fun configure(pin: String) {
        require(valid(pin)) { "Use a 6–12 digit PIN" }
        check(!isConfigured()) { "PIN already configured" }
        val salt = ByteArray(16).also(rng::nextBytes)
        val digest = derive(pin, salt)
        val ok = prefs.edit()
            .putString("pin_salt_v2", toHex(salt))
            .putString("pin_hash_v2", toHex(digest))
            .commit()
        digest.fill(0)
        if (!ok) throw IllegalStateException("Could not save PIN")
    }

    fun verify(pin: String): Boolean {
        if (!valid(pin)) return false
        val saltHex = prefs.getString("pin_salt_v2", null) ?: return false
        val hashHex = prefs.getString("pin_hash_v2", null) ?: return false
        return try {
            val actual = derive(pin, fromHex(saltHex))
            val expected = fromHex(hashHex)
            val result = MessageDigest.isEqual(actual, expected)
            actual.fill(0)
            result
        } catch (_: Exception) {
            false
        }
    }

    companion object {
        fun valid(pin: String) = pin.length in 6..12 && pin.all { it in '0'..'9' }

        private fun derive(pin: String, salt: ByteArray): ByteArray {
            val chars = pin.toCharArray()
            val spec = PBEKeySpec(chars, salt, 210_000, 256)
            return try {
                SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec).encoded
            } finally {
                spec.clearPassword()
                chars.fill('\u0000')
            }
        }

        private fun toHex(bytes: ByteArray): String =
            bytes.joinToString("") { "%02x".format(it.toInt() and 0xff) }

        private fun fromHex(hex: String): ByteArray {
            require(hex.length % 2 == 0)
            return ByteArray(hex.length / 2) { i ->
                hex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
            }
        }
    }
}
