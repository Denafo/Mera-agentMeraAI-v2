package com.demor.meraai

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputType
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var store: MemoryStore
    private lateinit var brain: Brain
    private lateinit var pinLock: PinLock
    private var unlocked = false
    private var pendingModelUri: Uri? = null
    private var pinFailures = 0
    private var blockedUntil = 0L
    private var storageError: String? = null

    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendBtn: Button
    private lateinit var statusView: TextView

    private val io = Executors.newSingleThreadExecutor()

    @Volatile
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("mera_ai", MODE_PRIVATE)
        pinLock = PinLock(prefs)
        brain = Brain()
        showPinGate()
    }

    /** Never create/read memory or show chat content before PIN validation. */
    private fun showPinGate() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(Color.parseColor("#0F1115"))
        }
        val title = TextView(this).apply {
            text = "Mera AI  •  Private"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, dp(60)))
        val status = TextView(this).apply {
            text = storageError ?: if (pinLock.isConfigured()) "Apna PIN daalo" else "Naya 6–12 digit PIN banao"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#D1D5DB"))
        }
        root.addView(status, LinearLayout.LayoutParams(-1, dp(60)))
        val entry = EditText(this).apply {
            hint = "Private PIN"
            textSize = 19f
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            isSingleLine = true
        }
        root.addView(entry, LinearLayout.LayoutParams(-1, dp(62)))
        val button = Button(this).apply {
            text = if (pinLock.isConfigured()) "Unlock" else "Set PIN"
            isAllCaps = false
        }
        root.addView(button, LinearLayout.LayoutParams(-1, dp(58)))
        var pendingPin: String? = null
        button.setOnClickListener {
            val value = entry.text.toString()
            entry.setText("")
            if (!PinLock.valid(value)) {
                status.text = "PIN 6–12 digits ka hona chahiye"
                return@setOnClickListener
            }
            if (pinLock.isConfigured()) {
                if (SystemClock.elapsedRealtime() < blockedUntil) {
                    status.text = "Bahut galat attempts. Thodi der baad try karo."
                    return@setOnClickListener
                }
                if (pinLock.verify(value)) {
                    pinFailures = 0
                    unlocked = true
                    openPrivateApp()
                } else {
                    pinFailures++
                    if (pinFailures >= 5) {
                        blockedUntil = SystemClock.elapsedRealtime() + 30_000
                        pinFailures = 0
                    }
                    status.text = "Galat PIN. Dobara try karo."
                }
            } else if (pendingPin == null) {
                pendingPin = value
                status.text = "Confirm karne ke liye wahi PIN dobara daalo"
                button.text = "Confirm PIN"
            } else {
                if (value == pendingPin) {
                    try {
                        pinLock.configure(value)
                        pendingPin = null
                        unlocked = true
                        openPrivateApp()
                    } catch (t: Throwable) {
                        status.text = "PIN save nahi hua: ${t.message}"
                    }
                } else {
                    pendingPin = null
                    button.text = "Set PIN"
                    status.text = "PIN match nahi hua. Naya PIN dobara banao."
                }
            }
        }
        setContentView(root)
    }

    private fun openPrivateApp() {
        if (!unlocked) return
        try {
            if (!this::store.isInitialized) store = MemoryStore(File(filesDir, "memory"))
            buildUi()
            val old = store.loadMessages(60)
            if (old.isEmpty()) addBubble(WELCOME, false)
            else for (m in old) addBubble(m.text, m.role == "user")
            val path = prefs.getString("model_path", null)
            if (brain.ready) refreshStatus()
            else if (path != null && File(path).exists()) loadModelAsync(path)
            else refreshStatus()
            pendingModelUri?.let { uri ->
                pendingModelUri = null
                importModel(uri)
            }
        } catch (t: Throwable) {
            storageError = "Encrypted memory khul nahi rahi: ${t.message ?: "unknown error"}"
            unlocked = false
            showPinGate()
        }
    }

    /** When leaving the app, cover the chat with the PIN screen. */
    override fun onStop() {
        super.onStop()
        if (unlocked) {
            unlocked = false
            showPinGate()
        }
    }

    override fun onDestroy() {
        io.execute { brain.close() }
        io.shutdown()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun ui(block: () -> Unit) {
        runOnUiThread { block() }
    }

    private fun buildUi() {
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#0F1115"))
        root.setPadding(dp(12), dp(12), dp(12), dp(8))

        // top bar
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL

        val title = TextView(this)
        title.text = "Mera AI"
        title.textSize = 22f
        title.setTextColor(Color.WHITE)
        title.setTypeface(title.typeface, Typeface.BOLD)
        top.addView(title, LinearLayout.LayoutParams(0, wrap, 1f))

        val modelBtn = Button(this)
        modelBtn.text = "Model"
        modelBtn.isAllCaps = false
        modelBtn.setOnClickListener { pickModel() }
        top.addView(modelBtn, LinearLayout.LayoutParams(wrap, wrap))

        val newBtn = Button(this)
        newBtn.text = "Naya chat"
        newBtn.isAllCaps = false
        newBtn.setOnClickListener { newChat() }
        top.addView(newBtn, LinearLayout.LayoutParams(wrap, wrap))

        root.addView(top, LinearLayout.LayoutParams(match, wrap))

        statusView = TextView(this)
        statusView.textSize = 12f
        statusView.setTextColor(Color.parseColor("#9CA3AF"))
        root.addView(statusView, LinearLayout.LayoutParams(match, wrap))

        val auto = CheckBox(this)
        auto.text = "Wikipedia search ki permission (internet)"
        auto.setTextColor(Color.parseColor("#D1D5DB"))
        auto.isChecked = prefs.getBoolean("auto_learn", false)
        auto.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("auto_learn", checked).apply()
        }
        root.addView(auto, LinearLayout.LayoutParams(match, wrap))

        // chat area
        scroll = ScrollView(this)
        chat = LinearLayout(this)
        chat.orientation = LinearLayout.VERTICAL
        scroll.addView(chat, ViewGroup.LayoutParams(match, wrap))
        root.addView(scroll, LinearLayout.LayoutParams(match, 0, 1f))

        // input row
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        input = EditText(this)
        input.hint = "Kuch bhi poochho ya kaam batao..."
        input.setTextColor(Color.WHITE)
        input.setHintTextColor(Color.parseColor("#6B7280"))
        input.inputType = InputType.TYPE_CLASS_TEXT or
            InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        input.maxLines = 5
        row.addView(input, LinearLayout.LayoutParams(0, wrap, 1f))

        sendBtn = Button(this)
        sendBtn.text = "Bhejo"
        sendBtn.isAllCaps = false
        sendBtn.setOnClickListener { onSend() }
        row.addView(sendBtn, LinearLayout.LayoutParams(wrap, wrap))

        root.addView(row, LinearLayout.LayoutParams(match, wrap))

        setContentView(root)
    }

    private fun addBubble(text: String, isUser: Boolean): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(Color.WHITE)
        tv.textSize = 15f
        tv.setTextIsSelectable(true)
        tv.setPadding(dp(12), dp(8), dp(12), dp(8))

        val bg = GradientDrawable()
        bg.cornerRadius = dp(14).toFloat()
        bg.setColor(Color.parseColor(if (isUser) "#2563EB" else "#1F2430"))
        tv.background = bg

        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.gravity = if (isUser) Gravity.END else Gravity.START
        lp.setMargins(dp(if (isUser) 48 else 0), dp(4), dp(if (isUser) 0 else 48), dp(4))
        chat.addView(tv, lp)
        scrollDown()
        return tv
    }

    private fun scrollDown() {
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun setStatus(s: String) {
        statusView.text = s
    }

    private fun refreshStatus() {
        val n = store.knowledgeCount()
        val s = if (brain.ready) {
            "Model taiyar ✓  |  saved yaadein: " + n
        } else {
            "Model load nahi hai - upar 'Model' dabake .litertlm file chuno  |  saved yaadein: " + n
        }
        ui { setStatus(s) }
    }

    // ---------------------------------------------------------------- model

    private fun pickModel() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        startActivityForResult(i, PICK_MODEL)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_MODEL && resultCode == Activity.RESULT_OK) {
            val uri = data?.data
            if (uri != null) {
                if (unlocked) importModel(uri)
                else pendingModelUri = uri
            }
        }
    }

    private fun queryName(uri: Uri): String? {
        val c = contentResolver.query(uri, null, null, null, null) ?: return null
        c.use {
            val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && it.moveToFirst()) return it.getString(idx)
        }
        return null
    }

    private fun importModel(uri: Uri) {
        val name = queryName(uri) ?: "model.litertlm"
        if (!name.lowercase().endsWith(".litertlm")) {
            ui { setStatus("Galat file: '" + name + "'. LiteRT-LM ko .litertlm model file chahiye.") }
            return
        }
        io.execute {
            try {
                brain.close()
                val dir = File(filesDir, "models")
                dir.mkdirs()
                val tmp = File(dir, "model.tmp")
                val dest = File(dir, "model.litertlm")

                val ins = contentResolver.openInputStream(uri)
                    ?: throw IllegalStateException("File khul nahi payi")
                ins.use { src ->
                    tmp.outputStream().use { out ->
                        val buf = ByteArray(1 shl 20)
                        var total = 0L
                        var lastShown = 0L
                        var n = src.read(buf)
                        while (n >= 0) {
                            out.write(buf, 0, n)
                            total += n
                            if (total - lastShown > 50L * 1024 * 1024) {
                                lastShown = total
                                val mb = total / (1024 * 1024)
                                ui { setStatus("Model copy ho raha hai: " + mb + " MB ...") }
                            }
                            n = src.read(buf)
                        }
                    }
                }
                if (dest.exists()) dest.delete()
                if (!tmp.renameTo(dest)) throw IllegalStateException("Model save nahi ho paya")
                prefs.edit().putString("model_path", dest.absolutePath).apply()
                loadModelAsync(dest.absolutePath)
            } catch (t: Throwable) {
                ui { setStatus("Model import error: " + (t.message ?: t.toString())) }
            }
        }
    }

    private fun loadModelAsync(path: String) {
        ui { setStatus("Model load ho raha hai... (thodi der lag sakti hai)") }
        io.execute {
            try {
                brain.load(path)
                refreshStatus()
            } catch (t: Throwable) {
                ui {
                    setStatus("Model load error: " + (t.message ?: t.toString()))
                    addBubble("Model load nahi ho paya: " + (t.message ?: t.toString()), false)
                }
            }
        }
    }

    // ---------------------------------------------------------------- chat

    private fun newChat() {
        if (busy) return
        chat.removeAllViews()
        addBubble("Naya chat shuru. Meri saved yaadein (memory) wahi hain.", false)
        io.execute {
            store.clearChat()
            brain.reset()
        }
    }

    private fun onSend() {
        val text = input.text.toString().trim()
        if (text.isEmpty() || busy) return
        input.setText("")
        addBubble(text, true)
        busy = true
        sendBtn.isEnabled = false
        io.execute {
            try {
                store.addMessage("user", text)
                if (text.startsWith("/")) handleCommand(text) else answer(text)
            } catch (t: Throwable) {
                reply("Error: " + (t.message ?: t.toString()))
            } finally {
                ui {
                    busy = false
                    sendBtn.isEnabled = true
                }
            }
        }
    }

    /** Bot ka chhota message dikhao aur save karo. */
    private fun reply(text: String) {
        store.addMessage("assistant", text)
        ui { addBubble(text, false) }
    }

    private fun answer(text: String) {
        var hits = store.search(text, 3)

        if (hits.isEmpty() && prefs.getBoolean("auto_learn", false) && Web.online(this)) {
            ui { setStatus("Internet se seekh raha hoon...") }
            val found = try {
                Web.wiki(text)
            } catch (e: Exception) {
                null
            }
            if (found != null) {
                store.addKnowledge(found.first, found.second, "wikipedia")
                hits = store.search(text, 3)
                if (hits.isEmpty()) {
                    hits = listOf(MemoryStore.Entry(found.first, found.second, "wikipedia"))
                }
            }
            refreshStatus()
        }

        if (!brain.ready) {
            if (hits.isEmpty()) {
                reply("Model abhi load nahi hai. Upar 'Model' dabake .litertlm file chuno. /help bhi dekh sakte ho.")
            } else {
                val sb = StringBuilder("Model load nahi hai, par meri saved jaankari me ye mila:\n")
                for (h in hits) sb.append("\n- ").append(h.title).append(": ").append(h.text.take(500))
                reply(sb.toString())
            }
            return
        }

        val prompt: String
        if (hits.isEmpty()) {
            prompt = text
        } else {
            val ctx = StringBuilder()
            for (h in hits) {
                ctx.append("- [").append(h.title).append("] ").append(h.text.take(700)).append("\n")
            }
            prompt = "Saved jaankari:\n" + ctx.toString() + "\nSawal/kaam: " + text
        }

        // jawab ka bubble pehle bana lo, phir usme stream karo
        val holder = arrayOfNulls<TextView>(1)
        val created = CountDownLatch(1)
        ui {
            holder[0] = addBubble("...", false)
            created.countDown()
        }
        created.await()
        val bubble = holder[0] ?: return

        val sb = StringBuilder()
        val errRef = AtomicReference<Throwable?>(null)
        val finished = CountDownLatch(1)
        try {
            brain.ask(
                prompt,
                { part ->
                    sb.append(part)
                    val s = sb.toString()
                    ui {
                        bubble.text = s
                        scrollDown()
                    }
                },
                { finished.countDown() },
                { t ->
                    errRef.set(t)
                    finished.countDown()
                }
            )
            if (!finished.await(10, TimeUnit.MINUTES)) {
                errRef.set(java.util.concurrent.TimeoutException("AI response timeout"))
            }
        } catch (t: Throwable) {
            errRef.set(t)
        }

        val err = errRef.get()
        var finalText = sb.toString().trim()
        if (err != null) {
            if (finalText.isEmpty()) finalText = "Error: " + (err.message ?: err.toString())
            brain.reset()
        }
        if (finalText.isEmpty()) {
            finalText = "(Model ne khali jawab diya. 'Naya chat' dabake dobara try karo.)"
        }
        store.addMessage("assistant", finalText)
        ui {
            bubble.text = finalText
            scrollDown()
        }
    }

    // ---------------------------------------------------------------- commands

    private fun handleCommand(text: String) {
        val cmd = text.substringBefore(' ').lowercase()
        val arg = text.substringAfter(' ', "").trim()

        when (cmd) {
            "/help" -> reply(HELP)

            "/remember" -> {
                if (arg.isEmpty()) {
                    reply("Aise likho: /remember mera favourite rang neela hai")
                } else {
                    store.addKnowledge("Meri jaankari", arg, "user")
                    refreshStatus()
                    reply("Yaad rakh liya ✓")
                }
            }

            "/learn" -> {
                if (arg.isEmpty()) {
                    reply("Aise likho: /learn Mumbai")
                } else if (!Web.online(this)) {
                    reply("Internet nahi hai. Net chalu karke dobara try karo.")
                } else {
                    ui { setStatus("Seekh raha hoon...") }
                    val found = Web.wiki(arg)
                    if (found == null) {
                        reply("'" + arg + "' ke baare me Wikipedia par kuch nahi mila.")
                    } else {
                        store.addKnowledge(found.first, found.second, "wikipedia")
                        reply("Seekh liya ✓  " + found.first + "\n\n" + found.second.take(400))
                    }
                    refreshStatus()
                }
            }

            "/fetch" -> {
                if (arg.isEmpty()) {
                    reply("Aise likho: /fetch https://example.com/article")
                } else if (!Web.online(this)) {
                    reply("Internet nahi hai. Net chalu karke dobara try karo.")
                } else {
                    ui { setStatus("Page padh raha hoon...") }
                    val page = Web.page(arg)
                    val body = page.second.take(8000)
                    if (body.length < 50) {
                        reply("Is page se kaam ka text nahi mila.")
                    } else {
                        var part = 1
                        var i = 0
                        while (i < body.length) {
                            val end = minOf(i + 1200, body.length)
                            store.addKnowledge(page.first + " (part " + part + ")", body.substring(i, end), arg)
                            part++
                            i = end
                        }
                        reply("Page seekh liya ✓  " + page.first + "  (" + (part - 1) + " hisse)")
                    }
                    refreshStatus()
                }
            }

            "/memory" -> {
                val all = store.allKnowledge()
                if (all.isEmpty()) {
                    reply("Abhi koi saved yaad nahi hai.")
                } else {
                    val sb = StringBuilder("Saved yaadein: " + all.size + "\nAakhri 5:\n")
                    for (e in all.takeLast(5)) sb.append("- ").append(e.title).append("\n")
                    reply(sb.toString())
                }
            }

            "/forget" -> {
                if (arg.lowercase() == "all") {
                    store.clearKnowledge()
                    refreshStatus()
                    reply("Saari saved yaadein hata di.")
                } else {
                    reply("Saari yaadein hatane ke liye likho: /forget all")
                }
            }

            else -> reply("Ye command mujhe nahi pata. /help dekho.")
        }
    }

    companion object {
        private const val PICK_MODEL = 41

        private const val WELCOME =
            "Namaste! Main Mera AI hoon - aapka personal assistant.\n\n" +
                "1) Upar 'Model' dabake phone se .litertlm model file chuno (ek baar).\n" +
                "2) Phir offline bhi baat karo.\n" +
                "3) Wikipedia search permission enable karke internet se seekh sakta hoon.\n\n" +
                "Commands ke liye /help likho."

        private const val HELP =
            "Commands:\n" +
                "/remember <baat> - kuch yaad rakhwao\n" +
                "/learn <topic> - Wikipedia se seekho (net chahiye)\n" +
                "/fetch <link> - kisi web page se seekho (net chahiye)\n" +
                "/memory - saved yaadein dekho\n" +
                "/forget all - saari yaadein hatao\n\n" +
                "Baaki kuch bhi seedha likho - mail, plan, hisaab, sawal, kuch bhi."
    }
}
