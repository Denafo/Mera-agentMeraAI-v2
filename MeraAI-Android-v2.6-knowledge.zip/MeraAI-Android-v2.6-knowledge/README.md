# Mera AI v2.6 Knowledge Studio (Android native)

Based on the **user-tested v2.5.2 offline inference build**. This update improves *knowledge acquisition*, not neural network weight training. The same `.litertlm` offline model remains the brain and its reasoning ceiling still applies.

## New features

- **Teach offline Q&A:** `/teach What is my brand? => DEMOR`, then ask the same question without a model or internet. Answer saved encrypted, matched after normalization.
- **Local `.txt` and `.md` document import:** Tap **Sikhao / Import .txt .md**, select a file (max 192 KiB), preview it, then approve local encrypted storage. Stores up to 40 bounded sections per import. Files are never uploaded.
- **Research preview/approval:** `/research topic` (or `/learn topic`) previews Wikipedia content; `/fetch https://...` previews a web page. Neither automatically saves. `/savefound` explicitly saves it encrypted; `/discardfound` rejects it. Normal chat does not trigger automatic Wikipedia search, even if previous versions allowed it. Explicit searches send the query/URL to the requested public service.
- **Learning status:** `/trainstatus` reports taught Q&A, imported sections, memory and model status.
- **Prompt hygiene:** retrieved documents are marked as untrusted reference data, not executable instructions; still **not a security boundary** against prompt injection from documents.
- Preserves existing PIN, encrypted chat, multiple conversations, edit/delete memories, diagnostics, LiteRT-LM offline model, and suggestion review.

## Important privacy & upgrade notes

- Separate package ID `com.demor.meraai.knowledge26`: existing v2.5.2 app remains installed. Previous encrypted memories **do not transfer automatically**; keep v2.5.2 installed. In this test release re-teach only non-sensitive facts you want in the new app.
- Import only `.txt`/`.md` documents you trust and do not share passwords, recovery codes or secrets with any AI.
- APK **is not compiled or tested on device in this development environment**. Run GitHub Actions build and verify the APK on your phone before treating it as stable.
- The app is a private, small offline assistant. A GPT-6-level experience is not possible merely by prompting a 0.6B model; a future optional API connection could unlock stronger cloud models, subject to internet use, cost and privacy design.
- Improvements are suggestions, not self-modifying code. Approval never triggers arbitrary code execution.

## Testing sequence (new test app only)

1. Build the APK in GitHub Actions using `.github/workflows/build-meraai-v26.yml`.
2. Install **alongside** v2.5.2 (do not uninstall old app). Set your new PIN.
3. Send `/memorytest`, then `/teach What is my brand? => DEMOR`, then ask `What is my brand?` while offline **without** loading a model.
4. Import a simple `.txt` file containing your own test notes; approve preview; check `/trainstatus` and `/memory`.
5. With internet, use `/research Mars` and then `/discardfound`. Verify memory count unchanged. Repeat and `/savefound` only if the result is accurate.
6. Load your Qwen3 `.litertlm` model, turn network OFF, ask another simple question, and check memory retrieval.

## Longer-term roadmap

1. Portable *passphrase-protected* backup/restore of encrypted user memories between signed app versions.
2. Optional hosted model integration with clearly explained costs, per-turn opt-in, securely stored credentials and **no automatic sending of private memory**.
3. Hybrid retrieval: keyword matching today; local embeddings/vectors after device benchmarking.
4. Structured evaluation tests for knowledge relevance, safety, hallucination, latency and prompt injection.
