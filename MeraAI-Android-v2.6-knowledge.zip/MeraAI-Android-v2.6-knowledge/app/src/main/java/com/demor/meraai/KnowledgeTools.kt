package com.demor.meraai

/** Pure Kotlin helpers for local, approved knowledge; no network or Android dependencies. */
object KnowledgeTools {
    fun normalizeQuestion(raw: String): String = raw.trim().lowercase()
        .replace(Regex("[?!.।]+$"), "")
        .replace(Regex("\\s+"), " ").trim()

    /** `/teach question => answer` is explicit and does not change model weights. */
    fun parseLesson(raw: String): Pair<String, String>? {
        val n = raw.indexOf("=>")
        if (n < 0) return null
        val question = raw.substring(0, n).trim()
        val answer = raw.substring(n + 2).trim()
        if (question.length !in 3..300 || answer.length !in 1..3000) return null
        return question to answer
    }

    fun supportsDocument(name: String): Boolean {
        val n = name.lowercase()
        return n.endsWith(".txt") || n.endsWith(".md")
    }

    /** Limit encrypted document chunks to keep CPU/RAM and prompt retrieval bounded. */
    fun splitDocument(raw: String): List<String> {
        val text = raw.replace("\r\n", "\n").trim().take(48_000)
        if (text.isBlank()) return emptyList()
        val chunks = mutableListOf<String>()
        var index = 0
        while (index < text.length && chunks.size < 40) {
            var end = minOf(index + 1200, text.length)
            if (end < text.length) {
                val newline = text.lastIndexOf('\n', end - 1)
                if (newline > index + 600) end = newline + 1
            }
            val part = text.substring(index, end).trim()
            if (part.isNotBlank()) chunks.add(part)
            index = end
        }
        return chunks
    }
}
