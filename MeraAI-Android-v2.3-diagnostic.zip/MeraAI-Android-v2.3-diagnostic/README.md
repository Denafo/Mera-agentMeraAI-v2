# Mera AI 2.3 Diagnostic Android App

This is a **separate** Android app (`com.demor.meraai.diagnostic`) intended to narrow down why the original Mera AI closes on `/help` and model replies. It does NOT replace the original, cannot see its PIN, chat history or model, and won't delete original memory.

Changes:
- `/help` and `/crash` bypass model inference, encrypted memory storage, and background tasks. If `/help` still closes this diagnostic app, the problem is outside the original message persistence pipeline (for example a UI or system/native issue).
- Normal messages save safely: a broken Android Keystore or disk write no longer triggers a second write from the error handler. On save failure the UI shows an explicit warning. This prevents one source-code exception loop, but cannot cure native crashes or system OOM kills.
- `/memorytest` checks AES-GCM Android Keystore roundtrip in a disposable test file, without reading or deleting personal memory. `/status` shows approximate available phone RAM. `/unload` unloads the model from RAM.
- Model does **not** auto-load on startup in this diagnostic app. Model button imports a `.litertlm` model or loads an already imported one. This allows testing commands independently of model RAM usage.
- `/crash` reads a private, minimal last Java/Kotlin uncaught exception report; it intentionally omits exception messages and user prompts. Native crashes and Android low-memory kills may leave no report.
- Retains offline LiteRT-LM, PIN, Wikipedia opt-in, AES-GCM memory. Limited inference to 1024 input-context tokens and 160 output tokens in this diagnostic build.

Workflow file (`build-meraai-v23.yml`) builds the APK from this ZIP. Tested: source assertions and ZIP integrity; actual Android compilation and device testing have NOT been performed. Never uninstall or clear the original app until personal data is backed up.
