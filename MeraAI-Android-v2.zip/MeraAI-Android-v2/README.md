# Mera AI v2 — Private Android Source

Native Android (Kotlin) app, not a website or WebView. Based on user-provided MeraAI-Android.zip.

## Included

- Local PIN gate at startup and after returning from background (6–12 digits).
- PIN stored as a salted PBKDF2-SHA256 verifier, not plaintext.
- Chat history and remembered knowledge stored only on the phone using AES-256-GCM with an Android Keystore key, with atomic encrypted file writes. Migrates plaintext V1 memory files on first authenticated launch.
- Offline LiteRT-LM conversation with import of a compatible `.litertlm` file from Android's document picker; model itself is **not** bundled.
- Manual `/remember`, `/memory`, `/forget all`; `/learn` and `/fetch` need network; optional Wikipedia search is off by default.
- Gradle and LiteRT-LM dependencies pinned rather than `latest.release`.

## Known limitations and responsibilities

- **Not an APK.** This is source code. APK compilation and physical-device behavior have not been validated in this environment.
- **PIN security is not biometric hardware authentication.** 6-digit PINs have limited entropy; use a longer PIN. Losing the PIN cannot be recovered in the app.
- **No backup/restore yet**. Android backup is disabled because an exported encrypted database without its Keystore key cannot be restored. Uninstalling the app or clearing its data destroys the memory and model copy. Before you switch devices, a separately designed and user-authorized portable encrypted backup system is required.
- Memory retrieval is keyword-based. Saving new facts is not neural-network retraining; the app does not modify model weights or its own code.
- `.litertlm` files may use large amounts of RAM and storage; compatibility and speed depend on the model and phone. Internet access is only used for the explicit learning commands or user-enabled Wikipedia search.
- Only debug APK workflow is provided, for personal testing; never publicly share the debug APK or its build logs with personal info.

## Build with GitHub Actions (no computer)

For a **new private GitHub repository**, add both files to the root and workflow path:

1. Upload `MeraAI-Android-v2.zip` to repository root (leave it zipped).
2. Create `.github/workflows/build-apk.yml`, with the contents of the separately provided `build-apk-v2.yml` file. (The same workflow is also included inside this source ZIP for reference; GitHub cannot execute workflows still inside a ZIP.)
3. GitHub **Actions** → **Build Mera AI v2 APK** → **Run workflow**.
4. If successful, download the `MeraAI-v2-debug-APK` artifact from the run's **Artifacts** section, extract it, and test on a trusted Android phone.
5. If failed, `build-diagnostics` artifact captures the Gradle compilation log, when available. Fix source code, not just extracted files during CI.

The workflow extracts the ZIP and builds it with Gradle 8.11.1 + Java 17. Your existing `build-apk.yml` from V1 is not compatible with this package name and layout.

## Optional local checks

Run `python3 scripts/validate_project.py` for static source checks. This does **not** compile Kotlin. Build requires Android SDK + Gradle and the published Maven dependencies.

## Reference

LiteRT-LM documentation: https://developers.google.com/edge/litert-lm/android
Android LiteRT-LM 0.18.0 reference: https://developer.android.com/agents/skills/device-ai/litert/litert-lm/skill
