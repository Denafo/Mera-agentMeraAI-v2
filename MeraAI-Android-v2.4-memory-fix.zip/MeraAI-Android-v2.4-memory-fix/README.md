# Mera AI v2.4 — Memory Fix Diagnostic (Android)

This build addresses a confirmed problem in v2.3: `InvalidAlgorithmParameterException` while saving memory.

## Root cause and fix

Android Keystore AES-GCM keys with `setRandomizedEncryptionRequired(true)` **reject app-supplied IVs during encryption**. The previous source called `cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))`, so encrypted writes failed.

The updated `MemoryStore.write()` calls `cipher.init(Cipher.ENCRYPT_MODE, key)` to let Android Keystore generate a fresh GCM IV, retrieves it via `cipher.iv`, and stores it next to ciphertext in the existing MAI2 format. Decryption continues to supply the stored IV with `GCMParameterSpec(128, iv)`. Encryption and AAD binding remain enabled. No key reset or memory deletion is performed.

## Safe testing

This is a separate app (`com.demor.meraai.diagnostic24`, shown as *Mera AI Memory Test*). Installing it will not replace or read the original app or v2.3 diagnostic app. Keep the original installed.

1. Install the new APK and set a separate private PIN.
2. **Do not import a model yet.** Send `/help`.
3. Send `/memorytest`. Expected: `Encrypted memory test PASS`.
4. Send `/remember test memory works`, then `/memory` to verify saved storage.
5. Close and reopen the app and check `/memory` again to test persistence.
6. Only after these tests, import a compatible model and test offline response.

This project's static validation script tests source structure and checks that the invalid encryption pattern is gone; it cannot prove APK/device behavior. The GitHub Actions workflow builds an APK. Do not delete an existing app or clear its data.
