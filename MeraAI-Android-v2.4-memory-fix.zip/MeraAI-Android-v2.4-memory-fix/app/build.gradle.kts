import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.demor.meraai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.demor.meraai.diagnostic24"
        minSdk = 28
        targetSdk = 34
        versionCode = 5
        versionName = "2.4-memory-fix"
        ndk {
            abiFilters.add("arm64-v8a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }


    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

// Kotlin 2.4+ typed compiler DSL (matches Java 17 in compileOptions).
kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.18.0")
}
