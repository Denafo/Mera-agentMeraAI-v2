package com.demor.meraai

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.AtomicFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Chat and knowledge are encrypted at rest with an Android Keystore AES-GCM key.
 * Files remain on the phone. Android backup is disabled in the manifest.
 * Uninstall clears the data and the key. No cloud sync or portable backup in V2.
 */
class MemoryStore(private val dir: File) {
    data class Msg(val role: String, val text: String)
    data class Entry(val title: String, val text: String, val source: String)

    private val chat = File(dir, "chat_history.enc")
    private val knowledge = File(dir, "knowledge.enc")
    private val key: SecretKey by lazy { fetchKey() }

    init {
        check(dir.isDirectory || dir.mkdirs()) { "Cannot create private memory directory" }
        migrateLegacy()
    }

    @Synchronized
    fun addMessage(role: String, text: String) {
        val arr = read(chat)
        arr.put(JSONObject().put("r", role).put("t", text))
        write(chat, arr)
    }

    @Synchronized
    fun loadMessages(limit: Int): List<Msg> {
        val a = read(chat)
        val start = (a.length() - limit.coerceAtLeast(0)).coerceAtLeast(0)
        return (start until a.length()).mapNotNull { i ->
            a.optJSONObject(i)?.let { Msg(it.optString("r"), it.optString("t")) }
        }
    }

    /** Tests Android Keystore AES encryption without touching personal memory. */
    @Synchronized
    fun selfTest(): Boolean {
        val probe = File(dir, "encryption_probe.enc")
        return try {
            write(probe, JSONArray().put(JSONObject().put("probe", "ok")))
            read(probe).optJSONObject(0)?.optString("probe") == "ok"
        } finally {
            if (probe.exists()) probe.delete()
        }
    }

    @Synchronized
    fun clearChat() = write(chat, JSONArray())

    @Synchronized
    fun addKnowledge(title: String, text: String, source: String) {
        val arr = read(knowledge)
        arr.put(JSONObject().put("ti", title).put("tx", text).put("s", source))
        write(knowledge, arr)
    }

    @Synchronized
    fun allKnowledge(): List<Entry> {
        val a = read(knowledge)
        return (0 until a.length()).mapNotNull { i ->
            a.optJSONObject(i)?.let {
                Entry(it.optString("ti"), it.optString("tx"), it.optString("s"))
            }
        }
    }

    fun knowledgeCount() = allKnowledge().size

    @Synchronized
    fun clearKnowledge() = write(knowledge, JSONArray())

    fun search(query: String, limit: Int): List<Entry> {
        val words = tokens(query)
        if (words.isEmpty()) return emptyList()
        val need = if (words.size >= 2) 2 else 1
        return allKnowledge()
            .map { e -> e to words.count { (e.title + " " + e.text).lowercase().contains(it) } }
            .filter { it.second >= need }
            .sortedByDescending { it.second }
            .take(limit.coerceAtLeast(0))
            .map { it.first }
    }

    private fun tokens(s: String) = s.lowercase()
        .split(Regex("[^\\p{L}\\p{M}\\p{N}]+"))
        .filter { it.length >= 3 && it !in STOP }
        .distinct()

    private fun fetchKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun read(file: File): JSONArray {
        if (!file.exists()) return JSONArray()
        val bytes = AtomicFile(file).openRead().use { it.readBytes() }
        require(bytes.size >= 32 && bytes.copyOfRange(0, 4).contentEquals(MAGIC)) {
            "Invalid encrypted memory file: ${file.name}"
        }
        val iv = bytes.copyOfRange(4, 16)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        cipher.updateAAD(file.name.toByteArray(Charsets.UTF_8))
        val data = cipher.doFinal(bytes.copyOfRange(16, bytes.size))
        return JSONArray(String(data, Charsets.UTF_8))
    }

    private fun write(file: File, arr: JSONArray) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        // AndroidKeyStore with randomized encryption rejects caller-specified IVs.
        // Let the keystore generate a fresh, unique GCM IV on each encryption.
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val iv = requireNotNull(cipher.iv) { "Android Keystore did not return a GCM IV" }
        check(iv.size == 12) { "Unexpected AES-GCM IV size: ${iv.size}" }
        cipher.updateAAD(file.name.toByteArray(Charsets.UTF_8))
        val ciphertext = cipher.doFinal(arr.toString().toByteArray(Charsets.UTF_8))
        val atomic = AtomicFile(file)
        val output = atomic.startWrite()
        try {
            output.write(MAGIC)
            output.write(iv)
            output.write(ciphertext)
            atomic.finishWrite(output)
        } catch (t: Throwable) {
            atomic.failWrite(output)
            throw t
        }
    }

    /** Upgrade plaintext files from the prototype, without silently discarding existing memories. */
    private fun migrateLegacy() {
        for ((oldName, newFile) in listOf(
            "chat_history.jsonl" to chat,
            "knowledge.jsonl" to knowledge
        )) {
            val old = File(dir, oldName)
            if (!old.exists()) continue
            if (!newFile.exists()) {
                val arr = JSONArray()
                old.forEachLine(Charsets.UTF_8) { line ->
                    if (line.isNotBlank()) {
                        try { arr.put(JSONObject(line)) } catch (_: Exception) { /* skip corrupt record */ }
                    }
                }
                write(newFile, arr)
            }
            check(old.delete()) { "Unable to remove plaintext memory after migration" }
        }
    }

    companion object {
        private const val KEY_ALIAS = "com.demor.meraai.memory.aes.v2"
        private val MAGIC = byteArrayOf('M'.code.toByte(), 'A'.code.toByte(), 'I'.code.toByte(), '2'.code.toByte())
        private val STOP = setOf(
            "the", "and", "what", "how", "who", "why", "for", "with", "can", "you", "please",
            "kya", "hai", "hain", "kaise", "kaun", "kyu", "kyun", "mera", "meri", "mere",
            "aap", "tum", "batao", "bata", "mein", "par"
        )
    }
}
