#!/usr/bin/env python3
"""Fast source-structure checks (NOT a substitute for compiling or device testing)."""
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
manifest = root / 'app/src/main/AndroidManifest.xml'
source = root / 'app/src/main/java/com/demor/meraai'
assert (root / 'settings.gradle.kts').exists()
assert (root / 'app/build.gradle.kts').exists()
assert all((source / file).is_file() for file in
           ['MainActivity.kt', 'Brain.kt', 'Web.kt', 'MemoryStore.kt', 'PinLock.kt'])

app = ET.parse(manifest).getroot().find('application')
android_ns = '{http://schemas.android.com/apk/res/android}'
assert app is not None and app.attrib[android_ns + 'allowBackup'] == 'false'

brain = (source / 'Brain.kt').read_text()
assert 'MessageCallback' in brain and 'sendMessageAsync(prompt, callback)' in brain
main = (source / 'MainActivity.kt').read_text()
assert 'showPinGate()' in main and 'openPrivateApp()' in main
assert 'newSingleThreadExecutor()' in main
assert 'getBoolean("auto_learn", false)' in main
memory = (source / 'MemoryStore.kt').read_text()
assert 'AES/GCM/NoPadding' in memory and 'AndroidKeyStore' in memory
pin = (source / 'PinLock.kt').read_text()
assert 'PBKDF2WithHmacSHA256' in pin and 'MessageDigest.isEqual' in pin
build = (root / 'build.gradle.kts').read_text()
assert 'org.jetbrains.kotlin.android") version "2.4.21"' in build
app_build = (root / 'app/build.gradle.kts').read_text()
assert 'litertlm-android:0.18.0' in app_build
assert 'import org.jetbrains.kotlin.gradle.dsl.JvmTarget' in app_build
assert 'jvmTarget.set(JvmTarget.JVM_17)' in app_build
assert 'kotlinOptions {' not in app_build
assert 'compilerOptions {' in app_build
assert 'latest.release' not in app_build
print('PASS: Android structure, manifest, PIN, encrypted memory, Kotlin 2.4 compiler DSL')
print('NOTE: Kotlin compilation and real phone tests are separate.')

assert 'safeSaveMessage("user", text)' in main and 'safeSaveMessage("assistant", text)' in main
assert 'if (text.equals("/help", ignoreCase = true))' in main
assert 'store.addMessage("user", text)' not in main
assert 'store.addMessage("assistant", text)' not in main
assert 'CrashCapture.install(applicationContext)' in main
assert (source / 'CrashCapture.kt').exists()
assert 'fun selfTest(): Boolean' in memory
assert 'com.demor.meraai.diagnostic' in app_build
print('PASS: v2.3 diagnostics, safe-write error path and separate application ID')

# Regression checks for Android Keystore randomized GCM IV behavior.
assert 'cipher.init(Cipher.ENCRYPT_MODE, key)' in memory
assert 'val iv = requireNotNull(cipher.iv)' in memory
assert 'cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec' not in memory
assert 'GCMParameterSpec(128, iv)' in memory  # decryption keeps the stored IV
assert 'setRandomizedEncryptionRequired(true)' in memory
assert 'com.demor.meraai.diagnostic24' in app_build
print('PASS: Keystore-generated AES-GCM IV; safe decryption; independent v2.4 package')
